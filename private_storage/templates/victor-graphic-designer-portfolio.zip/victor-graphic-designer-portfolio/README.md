# Victor — Graphic Designer & Art Director Portfolio

Official Commercial License — Vikash Choudhary
Tech Stack: React 19, Vite, Tailwind CSS, Orbitron & Inter fonts
Repository: https://github.com/vikasjaat05/victor-portfolio-dist

## Quick Start
```bash
npm install
npm run dev
```

Commercial Rights Granted to Buyer.
