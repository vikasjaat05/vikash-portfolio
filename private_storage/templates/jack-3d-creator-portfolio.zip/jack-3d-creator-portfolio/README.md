# Jack — 3D Creator & Visual Designer Portfolio

Official Commercial License — Vikash Choudhary
Tech Stack: React 19, Vite, Tailwind CSS, Google Kanit typography
Repository: https://github.com/vikasjaat05/jack-portfolio-dist

## Quick Start
```bash
npm install
npm run dev
```

Commercial Rights Granted to Buyer.
