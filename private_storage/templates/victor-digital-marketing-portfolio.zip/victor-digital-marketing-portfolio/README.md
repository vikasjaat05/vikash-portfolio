# Victor — Digital Marketing Manager & Performance Marketer Portfolio

Official Commercial License — Vikash Choudhary
Tech Stack: React 19, Vite, Tailwind CSS, Instrument Serif & Plus Jakarta Sans
Live Demo: https://digital-marketing-portfolio-six-psi.vercel.app/

## Quick Start
```bash
npm install
npm run dev
```

Commercial Rights Granted to Buyer.
