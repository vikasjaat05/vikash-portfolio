# LGPSM — Future Forward Fashion Portfolio

Official Commercial License — Vikash Choudhary
Tech Stack: React 19, Next.js, Tailwind CSS, Dual-Image Canvas Spotlight Mask
Repository: https://github.com/vikasjaat05/lgpsm-fashion-dist

## Quick Start
```bash
npm install
npm run dev
```

Commercial Rights Granted to Buyer.
